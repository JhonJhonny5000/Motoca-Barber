/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.DAO;
import Model.Servico;
import java.util.ArrayList;
import java.utilArrayList;
/**
 *
 * @author celyn
 */
public class ServicoDAO {
    
    public void insert(Servico servico){
        Banco.servico.add(servico);
    }
    
    public boolean update(Servico servico){
        for (int i = 0; i < Banco.servico.size(); i++) {
            if(idSaoIguais(Banco.servico.get(i), servico)){
                Banco.servico.set(i, servico);
                return true;
            }
        }
        
        return false;
    }
    
    public ArrayList<Servico> selectAll(){
        return Banco.servico;
    }
    
    private boolean idSaoIguais(Servico servico, Servico servicoAComparar) {
        return servico.getId() == servicoAComparar.getId();
    }
}
