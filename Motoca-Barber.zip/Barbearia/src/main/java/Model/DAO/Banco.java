/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.DAO;

import Model.Agendamento;
import Model.Cliente;
import Model.Servico;
import Model.Usuario;
import java.util.ArrayList;

public class Banco{
    public static ArrayList<Usuario> usuario;
    public static ArrayList<Cliente> cliente;
    public static ArrayList<Servico> servico;
    public static ArrayList<Agendamento> agendamento;
    
    public static void inicia(){
        usuario = new ArrayList<Usuario>();
        cliente = new ArrayList<Cliente>();
        servico = new ArrayList<Servico>();
        agendamento = new ArrayList<Agendamento>();
        
        Usuario usuario1 = new Usuario(1, "barbeiro", 'M', "09/05/1996", "30212121", "barbeiro@barbeiro", "164684651", "Teste@123", "Admin"); 
        Usuario usuario2 = new Usuario(1, "estagiario", 'M', "29/10/2010", "295465", "estagiario@barbeiro", "519861951", "Teste@123", "User"); 

        Cliente cliente = new Cliente(1, "Alan Figueiredo", 'M' "30/01/1997", "65189648", "alan@figueiredo", "1876986195", "rua do alan", "78516");
        Cliente cliente = new Cliente(2, "Frederico Silva", 'M' "10/01/1997", "984656", "frederico@silva", "72197217367", "rua do silva", "2748934");
        Cliente cliente = new Cliente(3, "Jose tonks", 'M' "30/07/1997", "951289", "jose@tonks", "156181651", "rua do jose", "7257");
        Cliente cliente = new Cliente(4, "Tiao Pereira", 'M' "05/01/2000", "838384378", "tiao@pereira", "873876", "rua do asfalto", "576752");
        Cliente cliente = new Cliente(5, "joao Fraga", 'M' "18/10/1997", "65183873889648", "joao@fraga", "725783", "rua do picole", "1379562");
        Cliente cliente = new Cliente(6, "mateus Neves", 'M' "09/07/1995", "532387", "mateus@neves", "5788722", "rua do copo", "2398");
        Cliente cliente = new Cliente(7, "igor Oliveira", 'M' "31/01/1997", "8763873", "igor@oliveira", "2572", "rua do sabao", "23975");
        Cliente cliente = new Cliente(8, "tiago Cruz", 'M' "24/01/1987", "378388", "tiago@cruz", "256873", "rua do balde", "7959413");
        Cliente cliente = new Cliente(9, "Alan Figueiredo", 'M' "02/01/1999", "873897", "alan@figueiredo", "9354335", "rua do pc", "9852");
        Cliente cliente = new Cliente(10, "ricardo stutz", 'M' "29/01/2007", "8723729", "ricardo@stutz", "45283935", "rua do mouse", "2655");
        
        Servico servico1 = new Servico(1, "Corte Simples", 18);
        Servico servico2 = new Servico(2, "Corte Degrde", 30);
        Servico servico3 = new Servico(3, "Corte Simples", 15);
        Servico servico4 = new Servico(4, "Barba Desenhada", 25);
        Servico servico5 = new Servico(5, "Sobrancelhas", 10);
    }
}