/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller.Helper;

import Model.Usuario;
import View.Login;

/**
 *
 * @author celyn
 */
public class LoginHelper {
    
    private final Login view;

    public LoginHelper(Login view){
        this.view = view;
    }
    
    public Usuario obterModelo(){        
        String nome = view.getTextoUsuario_Login().getText();
        String senha = view.getTextoSenha_Login().getText();
        Usuario modelo = new Usuario(0, nome, senha);
        return modelo;
    }
    
    public void setModelo(Usuario modelo){
        String nome = modelo.getNome();
        String senha = modelo.getSenha();
        view.getTextoUsuario_Login().setText(nome);
        view.getTextoSenha_Login().setText(senha);       
    }
    
    public void limparTela(){
        view.getTextoUsuario_Login().setText("");
        view.getTextoSenha_Login().setText("");
    }
    
}
    

