/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;

import Model.Cliente;
import Model.Servico;
import Model.Usuario;

/**
 *
 * @author celyn
 */
public class Main {
    
    public satatic void main(String args) {
    
        String nome = "tiago";
        System.out.println(nome);
        
        Servico servico = new Servico (1, "brba", 30);
        
        System.out.println(servico.getDescricao());
        
        Cliente cliente = new Cliente(1, "tiago", "M", "32524178", "rua ARAXA", "255165156");
        System.out.println(cliente.getNome());
        
        Usuario usuario = new Usuario(1, "barbeiro", "senha");
        System.out.println(usuario.getNome());
    }
    
    
    
}
